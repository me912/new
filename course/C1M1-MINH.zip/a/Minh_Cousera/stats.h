/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h
 * @brief This file wile be include in stats.c. Containing some defination of function that use in stats.c
 * @author Nguyen Minh
 * @date 10/09/2020
 *
 */
 /**
 * print_statistics() - A function that prints the statistics of an array including minimum, maximum, mean, and median.
 * print_array() - Given an array of data and a length, prints the array to the screen
 * find_median() - Given an array of data and a length, returns the median value
 * find_mean() - Given an array of data and a length, returns the mean
 * find_maximum() - Given an array of data and a length, returns the maximum
 * find_minimum() - Given an array of data and a length, returns the minimum
 * sort_array() - Given an array of data and a length, sorts the array from largest to smallest. 
   (The zeroth Element should be the largest value, and the last element (n-1) should be the smallest value. )
 */

#ifndef __STATS_H__
#define __STATS_H__

/*
 *Given an array of data and a length, prints an array to screen.
 *type para: unsigned char pointer and int.
 */
void print_array(unsigned char *, int );

/*
 *Given an array of data and a length, find the median.
 *type para: unsigned char pointer and int.
 *return type: unsigned char.
 */
double find_median(unsigned char *, int );

 /*
 *Given an array of data and a length, find the mean.
 *type para: unsigned char pointer and int.
 *return type: unsigned char.
 */
float find_mean(unsigned char *, int );

/*
 *Given an array of data and a length, find the maximum.
 *type para: unsigned char pointer and int.
 *return type: unsigned char.
 */
unsigned char find_maximum(unsigned char *, int );

/*
 *Given an array of data and a length, find the minimum.
 *type para: unsigned char pointer and int.
 *return type: unsigned char.
 */
unsigned char find_minimum(unsigned char *, int );

/*
 *Given an array of data and a length, array will be sorted.
 *type para: unsigned char pointer and int.
 */
void sort_array(unsigned char *, int );

/*
 *Given an array of data and a length, prints the statistics of an array including minimum, maximum, mean, and median..
 *type para: unsigned char pointer and int.
 */
void print_statistics(unsigned char *, int );


#endif /* __STATS_H__ */

