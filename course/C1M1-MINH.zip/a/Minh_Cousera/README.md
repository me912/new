This Project contains:
1. stats.c - Implementation file for your C-programming code
2. stats.h - Header file for your C-programming code
3. README.md - Includes information on the author and the project
About author:
Name: Nguyen Ngoc Minh
Country: Viet Nam
Age: 19
Email: ngocminh112233@gmail.com
My github: https://github.com/me912 (Nothing here LoL :v)


